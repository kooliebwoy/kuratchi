# @kuratchi/js

Cloudflare Workers-native web framework with file-based routing, server actions, and Durable Object support.

## Install

```bash
npm install @kuratchi/js
```

## Quick start

```bash
npx kuratchi create my-app
cd my-app
bun run dev
```

## How it works

`kuratchi build` (or `kuratchi watch`) scans `src/routes/` and generates two files:

| File | Purpose |
|---|---|
| `.kuratchi/routes.js` | Compiled routes, actions, RPC handlers, and render functions |
| `.kuratchi/worker.js` | Stable wrangler entry — re-exports the fetch handler and all Durable Object classes |

Point wrangler at the entry and you're done. **No `src/index.ts` needed.**

```jsonc
// wrangler.jsonc
{
  "main": ".kuratchi/worker.js"
}
```

## Routes

Place `.html` files inside `src/routes/`. The file path becomes the URL pattern.

```
src/routes/page.html          → /
src/routes/items/page.html    → /items
src/routes/blog/[slug]/page.html → /blog/:slug
src/routes/layout.html        → shared layout wrapping all routes
```

### Route file structure

```html
<script>
  // Imports and server-side logic run on every request.
  // Exported functions become actions or RPC handlers automatically.
  import { getItems, addItem, deleteItem } from '$database/items';

  const items = await getItems();
</script>

<!-- Template — plain HTML with minimal extensions -->
<ul>
  for (const item of items) {
    <li>{item.title}</li>
  }
</ul>
```

The `$database/` alias resolves to `src/database/`. You can use any path alias configured in your tsconfig.

### Layout file

`src/routes/layout.html` wraps every page. Use `<slot></slot>` where page content renders:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>My App</title>
</head>
<body>
  <nav>
    <a href="/">Home</a>
    <a href="/items">Items</a>
  </nav>
  <main>
    <slot></slot>
  </main>
</body>
</html>
```

## Template syntax

### Interpolation

```html
<p>{title}</p>
<p>{=html rawHtml}</p>  <!-- unescaped, use carefully -->
```

### Conditionals

```html
if (items.length === 0) {
  <p>Nothing here yet.</p>
} else {
  <p>{items.length} items</p>
}
```

### Loops

```html
for (const item of items) {
  <li>{item.title}</li>
}
```

### Components

Import `.html` components from your `src/lib/` directory or from packages:

```html
<script>
  import Card from '$lib/card.html';
  import Badge from '@kuratchi/ui/badge.html';
</script>

<Card title="Stack">
  <Badge variant="success">Live</Badge>
</Card>
```

## Form actions

Export server functions from a route's `<script>` block and reference them with `action={fn}`. The compiler automatically registers them as dispatchable actions.

```html
<script>
  import { addItem, deleteItem } from '$database/items';
</script>

<!-- Standard form — POST-Redirect-GET -->
<form action={addItem} method="POST">
  <input type="text" name="title" required />
  <button type="submit">Add</button>
</form>
```

The action function receives the raw `FormData`:

```ts
// src/database/items.ts
export async function addItem(formData: FormData): Promise<void> {
  const title = formData.get('title') as string;
  // write to DB...
}
```

### Redirect after action

Call `redirect()` inside an action to send the user to a different URL after the POST:

```ts
import { redirect } from '@kuratchi/js';

export async function createItem(formData: FormData): Promise<void> {
  const id = await db.items.insert({ title: formData.get('title') });
  redirect(`/items/${id}`);
}
```

## Progressive enhancement

These `data-*` attributes wire up client-side interactivity without writing JavaScript.

### `data-action` — fetch action (no page reload)

Calls a server action via `fetch` and refreshes `data-refresh` targets when done:

```html
<button data-action="deleteItem" data-args={JSON.stringify([item.id])}>Delete</button>
<button data-action="toggleItem" data-args={JSON.stringify([item.id, true])}>Done</button>
```

The action function receives the args array as individual arguments:

```ts
export async function deleteItem(id: number): Promise<void> {
  await db.items.delete({ id });
}

export async function toggleItem(id: number, done: boolean): Promise<void> {
  await db.items.update({ id }, { done });
}
```

### `data-refresh` — partial refresh

After a `data-action` call succeeds, elements with `data-refresh` re-fetch their content:

```html
<section data-refresh="/items">
  for (const item of items) {
    <article>{item.title}</article>
  }
</section>
```

### `data-get` — client-side navigation

Navigate to a URL on click (respects `http:`/`https:` only):

```html
<div data-get="/items/{item.id}">Click to navigate</div>
```

### `data-poll` — polling

Refresh a section automatically on an interval (milliseconds):

```html
<div data-refresh="/status" data-poll="3000">
  {status}
</div>
```

### `data-select-all` / `data-select-item` — checkbox groups

Sync a "select all" checkbox with a group of item checkboxes:

```html
<input type="checkbox" data-select-all="todos" />

for (const todo of todos) {
  <input type="checkbox" data-select-item="todos" value={todo.id} />
}
```

## RPC

Export an `rpc` object from a route to expose server functions callable from client-side JavaScript. RPC names are replaced with opaque IDs at compile time — real function names are never exposed to the client.

```html
<script>
  import { getCount } from '$database/items';

  export const rpc = {
    getCount,
  };
</script>
```

Call from the client using the generated `rpc` helper:

```html
<script client>
  const result = await rpc.getCount();
</script>
```

## Durable Objects

Extend `kuratchiDO` to create a Durable Object class backed by SQLite. The `static binding` name must match the binding in `wrangler.jsonc`.

```ts
// src/server/notes.do.ts
import { kuratchiDO } from '@kuratchi/js';
import type { Note } from '../schemas/notes';

export default class NotesDO extends kuratchiDO {
  static binding = 'NOTES_DO';

  async getNotes(): Promise<Note[]> {
    return (await this.db.notes.orderBy({ created_at: 'desc' }).many()).data ?? [];
  }

  async addNote(title: string): Promise<void> {
    await this.db.notes.insert({ title });
  }

  async deleteNote(id: number): Promise<void> {
    await this.db.notes.delete({ id });
  }
}
```

Declare it in `kuratchi.config.ts` and in `wrangler.jsonc`. The compiler exports it from `.kuratchi/worker.js` automatically.

```jsonc
// wrangler.jsonc
{
  "durable_objects": {
    "bindings": [{ "name": "NOTES_DO", "class_name": "NotesDO" }]
  },
  "migrations": [
    { "tag": "v1", "new_sqlite_classes": ["NotesDO"] }
  ]
}
```

Call DO methods from your route via a stub module in `src/database/`:

```ts
// src/database/notes.ts
import { env } from 'cloudflare:workers';

function getStub() {
  return (env as any).NOTES_DO.get((env as any).NOTES_DO.idFromName('global'));
}

export const getNotes = () => getStub().getNotes();
export const addNote  = (title: string) => getStub().addNote(title);
export const deleteNote = (id: number) => getStub().deleteNote(id);
```

## Runtime APIs

These are available anywhere in server-side route code:

```ts
import {
  getCtx,      // ExecutionContext
  getRequest,  // Request
  getLocals,   // mutable locals bag for the current request
  getParams,   // URL params ({ slug: 'foo' })
  getParam,    // getParam('slug')
  redirect,    // redirect('/path', 302)
  goto,        // same as redirect — alias
} from '@kuratchi/js';
```

Environment bindings are accessed directly via the Cloudflare Workers API — no framework wrapper needed:

```ts
import { env } from 'cloudflare:workers';

const result = await env.DB.prepare('SELECT 1').run();
```

## `kuratchi.config.ts`

Optional. Required only when using framework integrations or Durable Objects.

```ts
import { defineConfig } from '@kuratchi/js';
import { kuratchiUiConfig } from '@kuratchi/ui/adapter';
import { kuratchiOrmConfig } from '@kuratchi/orm/adapter';
import { kuratchiAuthConfig } from '@kuratchi/auth/adapter';

export default defineConfig({
  ui: kuratchiUiConfig({ theme: 'default' }),
  orm: kuratchiOrmConfig({
    databases: {
      DB: { schema: appSchema },
      NOTES_DO: { schema: notesSchema, type: 'do' },
    },
  }),
  durableObjects: {
    NOTES_DO: { className: 'NotesDO' },
  },
  auth: kuratchiAuthConfig({
    cookieName: 'kuratchi_session',
    sessionEnabled: true,
  }),
});
```

Without `kuratchi.config.ts` the compiler falls back to defaults — just drop your route files in `src/routes/` and run `kuratchi build`.

## CLI

```bash
npx kuratchi build   # one-shot build
npx kuratchi watch   # watch mode (for use with wrangler dev)
```

## TypeScript & Worker types

```bash
npx wrangler types
```

Then include the generated types in `tsconfig.json`:

```json
{
  "compilerOptions": {
    "types": ["./worker-configuration.d.ts"]
  }
}
```
